package com.czios.yilianvpn;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.czios.yilianvpn.databinding.FragmentFirstBinding;
import com.czios.yilianvpn.vpn.service.MyVpnService;
import com.czios.yilianvpn.vpn.tunnel.RemoteTunnel;
import com.czios.yilianvpn.vpn.utils.ProxyConfig;
import com.czios.yilianvpn.vpn.utils.VpnServiceHelper;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    private Context ctx;
    private boolean isDestroy = false;
    private UpdateUITask updateUITask;
    public static boolean isRunning = false;
    public static boolean onStart = false;
    public static boolean onStop = false;
    private final Handler handler = new Handler();
    ProxyConfig.VpnStatusListener vpnStatusListener = new ProxyConfig.VpnStatusListener() {
        @Override
        public void onVpnStart(Context context) {
            handler.post(() -> {
                        isRunning = true;
                        onStart = false;
                        onStop = false;
                        updateUI();
                        System.out.println("vpn start");
                    }
            );
        }

        @Override
        public void onVpnEnd(Context context) {
            handler.post(() -> {
                        isRunning = false;
                        onStart = false;
                        onStop = false;
                        updateUI();
                        System.out.println("vpn stop");
                    }
            );
        }
    };

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        ctx = binding.getRoot().getContext();
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //清除vpn事件监听
        ProxyConfig.Instance.cleanVpnStatusListener();
        //注册事件监听
        ProxyConfig.Instance.registerVpnStatusListener(vpnStatusListener);
        //获取配置
        SecondFragment.readOptins(ctx);
        binding.buttonRun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onStart || onStop) {
                    return;
                }
                if (!isRunning) {
                    MyVpnService.errorMsg = "";
                    MyVpnService.closeByUser = false;
                    if (SecondFragment.getPreferenceValue(ctx, "new-install").equals("0")) {
                        SecondFragment.writeToPreference(ctx, "new-install", "no");
                        startVPN();
                        closeVpn();
                        MyVpnService.errorMsg = getString(R.string.please_reconnect);
                    } else {
                        onStart = true;
                        startVPN();
                    }
                } else {
                    MyVpnService.closeByUser = true;
                    onStop = true;
                    closeVpn();
                }
                updateUI();
            }
        });

        binding.buttonSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(FirstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment);
            }
        });
        // 启动任务
        updateUITask = new UpdateUITask();
        updateUITask.execute("arg");
        updateUI();
    }

    @Override
    public void onDestroyView() {
        binding = null;
        if (updateUITask != null) {
            updateUITask.cancel(true);
            updateUITask = null;
        }
        isDestroy = true;
        super.onDestroyView();
    }

    public void updateUI() {
        if(isDestroy) return;
        StringBuffer state = new StringBuffer();
        StringBuffer btnState = new StringBuffer();
        if (isRunning) {
            if (onStop) {
                state.append(ctx.getString(R.string.disconnecting));
                btnState.append(ctx.getString(R.string.disconnecting));
            } else {
                state.append(ctx.getString(R.string.connected));
                btnState.append(ctx.getString(R.string.stop_run));
            }
        } else {
            if (onStart) {
                state.append(ctx.getString(R.string.connecting));
                btnState.append(ctx.getString(R.string.connecting));
            } else {
                state.append(ctx.getString(R.string.not_connect));
                btnState.append(ctx.getString(R.string.start_run));
            }
        }

        StringBuffer errorMsg = new StringBuffer();
        StringBuffer vpnInfo = new StringBuffer();
        if (MyVpnService.errorMsg.length() > 0 && !MyVpnService.closeByUser) {
            errorMsg.append(ctx.getString(R.string.error_msg) + ":");
            errorMsg.append(MyVpnService.errorMsg);
            binding.vpnErrorMsg.setVisibility(View.VISIBLE);
        }else{
            binding.vpnErrorMsg.setVisibility(View.GONE);
        }

        vpnInfo.append(ctx.getString(R.string.state) + ":");
        vpnInfo.append(state + "\n");
        vpnInfo.append(ctx.getString(R.string.ip) + ":");
        vpnInfo.append(ProxyConfig.SERVER_IP + "\n");
        vpnInfo.append(ctx.getString(R.string.port) + ":");
        vpnInfo.append(ProxyConfig.SERVER_PORT + "\n");
        vpnInfo.append(ctx.getString(R.string.user_name) + ":");
        vpnInfo.append(ProxyConfig.USER_NAME + "\n");
        vpnInfo.append(ctx.getString(R.string.user_password) + ":");
        vpnInfo.append(ProxyConfig.USER_PWD + "\n");
        vpnInfo.append(ctx.getString(R.string.dns1) + ":");
        vpnInfo.append(ProxyConfig.DNS_FIRST + "\n");
        vpnInfo.append(ctx.getString(R.string.dns2) + ":");
        vpnInfo.append(ProxyConfig.DNS_SECOND + "\n");
        vpnInfo.append(ctx.getString(R.string.options_http_proxy_port) + ":");
        vpnInfo.append(ProxyConfig.HTTP_PROXY_PORT + "\n");
        vpnInfo.append(ctx.getString(R.string.run_http_proxy_on_start) + ":");
        String runProxy = ProxyConfig.RUN_HTTP_PROXY == 1 ? ctx.getString(R.string.yes) : ctx.getString(R.string.no);
        vpnInfo.append(runProxy);

        if(isRunning) {
            RemoteTunnel tunnel = VpnServiceHelper.getRemoteTunnel();
            if (tunnel != null) {
                vpnInfo.append("\n" + ctx.getString(R.string.server_info_note) + "\n");
                vpnInfo.append(ctx.getString(R.string.max_proxy_num) + tunnel.getMaxProxyNum() + "\n");
                vpnInfo.append(ctx.getString(R.string.tcp_proxy_num) + tunnel.getTcpProxyNum() + "\n");
                vpnInfo.append(ctx.getString(R.string.udp_proxy_num) + tunnel.getUdpProxyNum());
            }
        }

        binding.vpnErrorMsg.setText(errorMsg);
        binding.vpnInfo.setText(vpnInfo);
        binding.buttonRun.setText(btnState);
    }

    private void startVPN() {
        if (!VpnServiceHelper.vpnRunningStatus()) {
            VpnServiceHelper.changeVpnRunningStatus(ctx, true);
        }
    }

    private void closeVpn() {
        if (VpnServiceHelper.vpnRunningStatus()) {
            VpnServiceHelper.changeVpnRunningStatus(ctx, false);
        }
    }

    @SuppressLint("StaticFieldLeak")
    public class UpdateUITask extends AsyncTask<String, Integer, String> {

        @Override
        protected void onPreExecute() {
            // 启动代码
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected String doInBackground(String... urls) {
            // 后台代码
            String url = urls[0];
            boolean error = false;
            while (!error) {
                if(isRunning){
                    VpnServiceHelper.sendCtrlPacket((byte) 101, (short) 200);
                }
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    error = true;
                }
                // 发布进度
                publishProgress(0);
                // 检查是否被取消
                if (isCancelled()) {
                    return "已取消";
                }
            }
            return "下载完成: " + url;
        }

        @Override
        protected void onProgressUpdate(Integer... progress) {
            // 任务更新代码
            if(isRunning) {
                updateUI();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            // 结束代码
        }

        @Override
        protected void onCancelled() {
            // 取消代码
        }
    }

}