package com.czios.yilianvpn.vpn.service;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;


import com.czios.yilianvpn.R;
import com.czios.yilianvpn.vpn.httpProxy.ProxyHttpsServer;
import com.czios.yilianvpn.vpn.tcpip.ICMPHeader;
import com.czios.yilianvpn.vpn.tcpip.IPHeader;
import com.czios.yilianvpn.vpn.tcpip.TCPHeader;
import com.czios.yilianvpn.vpn.tcpip.UDPHeader;
import com.czios.yilianvpn.vpn.tunnel.RemoteTunnel;
import com.czios.yilianvpn.vpn.utils.AppDebug;
import com.czios.yilianvpn.vpn.utils.DebugLog;
import com.czios.yilianvpn.vpn.utils.ProxyConfig;
import com.czios.yilianvpn.vpn.utils.VpnServiceHelper;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MyVpnService extends VpnService implements Runnable {

    private static final String TAG = MyVpnService.class.getSimpleName();
    private static final String VPN_ROUTE = "0.0.0.0"; // Intercept everything
    private static int VPN_ID;
    private boolean closed = false;
    private Thread thread;
    private ParcelFileDescriptor vpnInterface;
    private FileOutputStream vpnOutputStream;
    private RemoteTunnel remoteTunnel = null;
    private SharedPreferences sp;
    private ProxyHttpsServer proxyHttpsServer = null;
    public static String errorMsg = "";
    public static boolean closeByUser = false;


    public MyVpnService() {
        VPN_ID++;
        DebugLog.i("New VPNService(%d)\n", VPN_ID);
    }

    //启动Vpn工作线程
    @Override
    public void onCreate() {
        super.onCreate();
        DebugLog.i("VPNService(%s) created.\n", VPN_ID);
        String VPN_SP_NAME = "vpn_sp_name";
        sp = getSharedPreferences(VPN_SP_NAME, Context.MODE_PRIVATE);
        VpnServiceHelper.onVpnServiceCreated(this);
        thread = new Thread(this, "VPNServiceThread");
        thread.start();
        if(ProxyConfig.RUN_HTTP_PROXY == 1){
            proxyHttpsServer = new ProxyHttpsServer(ProxyConfig.HTTP_PROXY_PORT);
            proxyHttpsServer.startService();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    //停止Vpn工作线程
    @Override
    public void onDestroy() {
        super.onDestroy();
        DebugLog.i("VPNService(%s) destroyed.\n", VPN_ID);
        if (thread != null) {
            thread.interrupt();
            thread = null;
        }
        if(proxyHttpsServer != null){
            proxyHttpsServer.close();
            proxyHttpsServer = null;
        }
        VpnServiceHelper.onVpnServiceDestroy();
    }


    private void runVPN() throws Exception {
        vpnInterface = establishVPN();
        ProxyConfig.Instance.onVpnStart(this);
        startStream();
    }

    private void startStream() throws IOException {
        byte[] packet = new byte[ProxyConfig.MUTE];
        FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
        vpnOutputStream = new FileOutputStream(vpnInterface.getFileDescriptor());
        int size = 0;
        while (size != -1 && !closed) {
            size = in.read(packet);
            if (size > 0) {
                onIPPacketReceived(packet, 0, size);
            }
        }
        in.close();
        vpnOutputStream.close();
        vpnOutputStream = null;
    }

    public void onIPPacketReceived(byte[] bytes, int offset, int size) {
        IPHeader ipHeader = new IPHeader(bytes, offset);
        switch (ipHeader.getProtocol()) {
            case IPHeader.TCP:
            case IPHeader.UDP:
                remoteTunnel.processPacket(bytes, offset, size);
                break;
            case IPHeader.ICMP:
                onIPCMPacketReceived(bytes, offset, size);
                break;
            default:
                DebugLog.i("服务器无法处理的IP协议包 %s\n", ipHeader);
                break;
        }
    }

    /*
    //icmp报文(能到达目的地,响应-请求包)
    struct icmp8
    {
        u_char icmp_type; //type of message(报文类型)
        u_char icmp_code; //type sub code(报文类型子码)
        u_short icmp_cksum;
        u_short icmp_id;
        u_short icmp_seq;
        char icmp_data[ 1];
    };
    */

    public void onIPCMPacketReceived(byte[] bytes, int offset, int size) {
        IPHeader ipHeader = new IPHeader(bytes, offset);
        ICMPHeader icmpHeader = new ICMPHeader(bytes, offset + IPHeader.IP4_HEADER_SIZE);
        int srcIp = ipHeader.getSourceIP();
        int destIp = ipHeader.getDestinationIP();
        ipHeader.setSourceIP(destIp);
        ipHeader.setDestinationIP(srcIp);

        boolean canReply = true;
        if(icmpHeader.getType() ==  8 && icmpHeader.getCode() == 0){
            icmpHeader.setType((byte) 0);
            icmpHeader.setCode((byte) 0);
        }else if(icmpHeader.getType() == 13 && icmpHeader.getCode() == 0){
            icmpHeader.setType((byte) 14);
            icmpHeader.setCode((byte) 0);
        }else if(icmpHeader.getType() == 17 && icmpHeader.getCode() == 0){
            icmpHeader.setType((byte) 18);
            icmpHeader.setCode((byte) 0);
        }else{
            canReply = false;
        }
        if(canReply){
            icmpHeader.ComputeIPChecksum(ipHeader);
            write(bytes, offset, size);
        }
    }

    public boolean packetCheck(byte[] packet, int offset, int size) {
        boolean badPacket = false;
        IPHeader ipHeader = new IPHeader(packet, offset);
        int oldCrc = ipHeader.getCrc();
        ipHeader.ComputeIPChecksum();
        int newCrc = ipHeader.getCrc();
        if(oldCrc != newCrc){
            badPacket = true;
            DebugLog.i("write error: bad ip packet crc.");
        }
        if(!badPacket) {
            switch (ipHeader.getProtocol()) {
                case IPHeader.ICMP:
                    break;
                case IPHeader.TCP:
                    TCPHeader tcpHeader = new TCPHeader(packet, (offset + IPHeader.IP4_HEADER_SIZE));
                    oldCrc = tcpHeader.getCrc();
                    tcpHeader.ComputeTCPChecksum(ipHeader);
                    newCrc = tcpHeader.getCrc();
                    if(oldCrc != newCrc){
                        badPacket = true;
                    }
                    break;
                case IPHeader.UDP:
                    UDPHeader udpHeader = new UDPHeader(packet, offset + IPHeader.IP4_HEADER_SIZE);
                    oldCrc = udpHeader.getCrc();
                    udpHeader.ComputeUDPChecksum(ipHeader);
                    newCrc = udpHeader.getCrc();
                    if(oldCrc != newCrc){
                        badPacket = true;
                    }
                    break;
                default:
                    DebugLog.i("收到无法处理的IP协议包 %s.\n", ipHeader);
                    badPacket = true;
                    break;
            }
        }
        if(!badPacket){
            return true;
        }else{
            DebugLog.i("VpnService error: 收到数据包校验错误, 将关闭VPN");
            setVpnClosedStatus(true);
            addErrorMsg(getString(R.string.rev_bad_packet));
            return false;
        }
    }
    public void write(byte[] packet, int offset, int size) {
        if (AppDebug.SAFE_CHECK) {
            boolean isSafe = packetCheck(packet, offset, size);
            if(!isSafe) return;
        }
        try {
            if(vpnOutputStream != null)
                vpnOutputStream.write(packet, offset, size);
        } catch (IOException e) {
            IPHeader ipHeader = new IPHeader(packet, offset);
            DebugLog.eWithTag(TAG, "write packet(%s) error: ", ipHeader);
            if (AppDebug.IS_DEBUG) {
                e.printStackTrace();
            }
        }
    }

    private void waitUntilPrepared() {
        while (prepare(this) != null) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                if (AppDebug.IS_DEBUG) {
                    e.printStackTrace();
                }
                DebugLog.e("waitUntilPrepared catch an exception %s\n", e);
            }
        }
    }

    private ParcelFileDescriptor establishVPN() {
        Builder builder = new Builder();
        builder.setMtu(ProxyConfig.MUTE);
        DebugLog.i("setMtu: %d\n", ProxyConfig.MUTE);

        ProxyConfig.IPAddress ipAddress = ProxyConfig.Instance.getDefaultLocalIP();
        builder.addAddress(ipAddress.Address, ipAddress.PrefixLength);
        DebugLog.i("addAddress: %s/%d\n", ipAddress.Address, ipAddress.PrefixLength);

        builder.addRoute(VPN_ROUTE, 0);
        DebugLog.i("addRoute: %s\n", VPN_ROUTE);

        builder.addDnsServer(ProxyConfig.DNS_FIRST);
        DebugLog.i("addDnsServer1: %s\n", ProxyConfig.DNS_FIRST);
        builder.addDnsServer(ProxyConfig.DNS_SECOND);
        DebugLog.i("addDnsServer2: %s\n", ProxyConfig.DNS_SECOND);

        String[] disallowedApplications = {
                "com.czios.yilianvpntunnel",
        };
        for(String appPackage : disallowedApplications){
            try {
                builder.addDisallowedApplication(appPackage);
                DebugLog.i("addDisallowedApplication: %s\n", appPackage);
            } catch (PackageManager.NameNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
        builder.setSession(getString(R.string.app_name));
        return builder.establish();
    }

    @Override
    public void run() {
        try {
            DebugLog.i("VPNService(%s) work thread is Running...\n", VPN_ID);
            waitUntilPrepared();
            //启动TCP数据通道
            remoteTunnel = new RemoteTunnel(this);
            remoteTunnel.start();
            if(!remoteTunnel.isClose()){
                runVPN();
                addErrorMsg(getString(R.string.app_close_by_system));
            }else{
                addErrorMsg(getString(R.string.app_close_by_can_not_connect_server));
            }
        } catch (Exception e) {
            DebugLog.e("VpnService run catch an exception %s.\n", e);
            if (AppDebug.IS_DEBUG) {
                e.printStackTrace();
            }
            addErrorMsg(getString(R.string.app_close_by_catch_error));
        } finally {
            DebugLog.i("VpnService terminated");
            dispose();
            setVpnClosedStatus(true);
            ProxyConfig.Instance.onVpnEnd(this);
        }
    }

    public void sendCtrlPacket(byte state, short code){
        if(remoteTunnel != null){
            remoteTunnel.sendCtrlPacket(state, code);
        }
    }

    public synchronized void dispose() {
        try {
            if(!remoteTunnel.isClose()){
                remoteTunnel.close(getString(R.string.tunnel_close_on_dispose));
                remoteTunnel = null;
            }
            if(vpnInterface != null) {
                vpnInterface.close();
                vpnInterface = null;
            }
            stopSelf();
            addErrorMsg(getString(R.string.app_close_on_dispose));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void addErrorMsg(String msg){
        if(MyVpnService.errorMsg.length() > 0){
            MyVpnService.errorMsg = MyVpnService.errorMsg + "->" + msg;
        }else{
            MyVpnService.errorMsg = msg;
        }

    }
    public RemoteTunnel getRemoteTunnel(){
        return remoteTunnel;
    }
    public boolean vpnRunningStatus() {
        return !closed;
    }

    public void setVpnClosedStatus(boolean closed) {
        this.closed = closed;
    }
}
