package com.czios.yilianvpn.vpn.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.czios.yilianvpn.vpn.service.MyVpnService;
import com.czios.yilianvpn.vpn.tunnel.RemoteTunnel;

public class VpnServiceHelper {
    private static Context context;
    public static final int START_VPN_SERVICE_REQUEST_CODE = 1;
    private static MyVpnService sMyVpnService = null;

    public static MyVpnService getsMyVpnService() {
        return sMyVpnService;
    }
    public static void onVpnServiceCreated(MyVpnService myVpnService) {
        sMyVpnService = myVpnService;
        if(context==null){
            context= myVpnService.getApplicationContext();
        }
    }

    public static void onVpnServiceDestroy() {
        sMyVpnService = null;
    }


    public static Context getContext() {
        return context;
    }

    public static boolean vpnRunningStatus() {
        if (sMyVpnService != null) {
            return sMyVpnService.vpnRunningStatus();
        }
        return false;
    }

    public static void changeVpnRunningStatus(Context context, boolean isStart) {
        if (context == null) {
            return;
        }
        if (isStart) {
            Intent intent = MyVpnService.prepare(context);
            if (intent == null) {
                startVpnService(context);
            } else {
                if (context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, START_VPN_SERVICE_REQUEST_CODE);
                }
            }
        } else if (sMyVpnService != null) {
            sMyVpnService.setVpnClosedStatus(true);
        }
    }

    public static void startVpnService(Context context) {
        if (context == null) {
            return;
        }
        context.startService(new Intent(context, MyVpnService.class));
    }

    public static void sendCtrlPacket(byte code, short state) {
        if (sMyVpnService != null) {
            sMyVpnService.sendCtrlPacket(code, state);
        }
    }

    public static RemoteTunnel getRemoteTunnel() {
        if (sMyVpnService != null) {
            return sMyVpnService.getRemoteTunnel();
        }
        return null;
    }
}
