package com.czios.yilianvpn.vpn.tunnel;

import com.czios.yilianvpn.R;
import com.czios.yilianvpn.vpn.utils.AppDebug;
import com.czios.yilianvpn.vpn.utils.CommonMethods;
import com.czios.yilianvpn.vpn.utils.ProxyConfig;
import com.czios.yilianvpn.vpn.service.MyVpnService;
import com.czios.yilianvpn.vpn.tcpip.IPHeader;
import com.czios.yilianvpn.vpn.utils.DebugLog;

import java.io.IOException;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;


public class RemoteTunnel implements Runnable {

    private static final String TAG = RemoteTunnel.class.getSimpleName();
    private MyVpnService myVpnService = null;
    private SocketChannel socketChannel = null;
    private boolean closed = false;
    private final byte[] cacheBytes = new byte[ProxyConfig.MUTE * 2];
    private int cacheBytesSize = 0;
    private Thread thread = null;
    private String ipAndPort;
    public static byte CTRL = (byte) 203;
    private int vpnClientNum = 0;
    private int maxProxyNum = 0;
    private int tcpProxyNum = 0;
    private int udpProxyNum = 0;
    private int upDataBytes = 0;
    private int downDataBytes = 0;


    public RemoteTunnel(MyVpnService myVpnService) {
        ipAndPort = ProxyConfig.SERVER_IP + ":" + ProxyConfig.SERVER_PORT;
        this.myVpnService = myVpnService;
    }

    public void start() {
        DebugLog.iWithTag(TAG, "Connecting server(%s).", ipAndPort);
        try {
            socketChannel = SocketChannel.open();
            socketChannel.configureBlocking(true);
            socketChannel.connect(new InetSocketAddress(ProxyConfig.SERVER_IP, ProxyConfig.SERVER_PORT));
            myVpnService.protect(socketChannel.socket());
            sendCtrlPacket((byte) 100, (short) 200); //发送登录包
            DebugLog.iWithTag(TAG, "Connect server(%s) succeed.", ipAndPort);
            thread = new Thread(this, TAG);
            thread.start();
        } catch (IOException e) {
            DebugLog.dWithTag(TAG, "Connect server(%s) fail.", ipAndPort);
            close(myVpnService.getString(R.string.can_not_connect_server));
        }
    }

    public void sendCtrlPacket(byte state, short code) {
        byte[] header = new byte[IPHeader.IP4_HEADER_SIZE];
        IPHeader ipheader = new IPHeader(header, 0);
        ipheader.setHeaderLength(IPHeader.IP4_HEADER_SIZE);
        ipheader.setTotalLength(IPHeader.IP4_HEADER_SIZE);
        ipheader.setSourceIP(ProxyConfig.USER_NAME);
        ipheader.setDestinationIP(ProxyConfig.USER_PWD);
        ipheader.setTos(state);
        ipheader.setIdentification(code);
        ipheader.setProtocol(RemoteTunnel.CTRL);
        processPacket(header, 0, IPHeader.IP4_HEADER_SIZE);
    }

    //发送给服务器
    public void processPacket(byte[] bytes, int offset, int size) {
        try {
            myVpnService.upDataBytes.addAndGet(size);
            socketChannel.write(ByteBuffer.wrap(bytes, offset, size));
        } catch (IOException e) {
            DebugLog.wWithTag(TAG, "Network write error: %s %s", ipAndPort, e);
            close(myVpnService.getString(R.string.send_packet_error));
        }
    }

    //关闭通道
    public void close(String errMsg) {
        if(closed){
            errMsg = errMsg + "!";
        }
        closed = true;
        if(MyVpnService.errorMsg.length() > 0){
            MyVpnService.errorMsg = MyVpnService.errorMsg + "->" + errMsg;
        }else{
            MyVpnService.errorMsg = errMsg;
        }
        myVpnService.setVpnClosedStatus(true);
        if (thread != null){
            //thread.interrupt();
            thread = null;
        }
        try {
            if(socketChannel != null){
                socketChannel.close();
                socketChannel = null;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean isClose() {
        return closed;
    }

    public void processCTRLPacket(byte[] packet, int offset){
        IPHeader ipHeader = new IPHeader(packet, offset);
        maxProxyNum = ipHeader.getFlagsAndOffset();
        int state = ipHeader.getTos();
        if(state == 100){
            int code = ipHeader.getIdentification();
            switch (code) {
                case 200:
                    //用户验证成功
                    String msg = myVpnService.getString(R.string.user_verify_succeed);
                    System.out.println(msg);
                    break;
                case 400:
                    close(myVpnService.getString(R.string.server_close_client));
                    break;
                case 401:
                    close(myVpnService.getString(R.string.server_check_packet_error));
                    break;
                case 402:
                    close(myVpnService.getString(R.string.server_client_expire));
                    break;
                case 403:
                    close(myVpnService.getString(R.string.user_verify_fail));
                    break;
                case 404:
                    close(myVpnService.getString(R.string.server_on_max_client_connect));
                    break;
                default:
                    close(myVpnService.getString(R.string.server_connect_ctrl_packet_unknown_code) + "code:" + state);
                    break;
            }
        }else if(state == 101){
            vpnClientNum = ipHeader.getCrc();
            tcpProxyNum = ipHeader.getSourceIP();
            udpProxyNum = ipHeader.getDestinationIP();
            upDataBytes = CommonMethods.readInt(packet, offset + IPHeader.IP4_HEADER_SIZE);
            downDataBytes = CommonMethods.readInt(packet, offset + IPHeader.IP4_HEADER_SIZE + 4);
        }
    }

    public int processRevPacket(byte[] packet, int offset, int size) {
        IPHeader ipHeader = new IPHeader(packet, offset);
        byte protocol = ipHeader.getProtocol();
        if (protocol == IPHeader.TCP) {
            myVpnService.write(packet, offset, size);
        } else if (protocol == IPHeader.UDP) {
            myVpnService.write(packet, offset, size);
        } else if (protocol == IPHeader.ICMP) {
            myVpnService.write(packet, offset, size);
        } else if (protocol == RemoteTunnel.CTRL) {
            processCTRLPacket(packet, offset);
        } else {
            DebugLog.dWithTag(TAG, "Recv(%s) unknown protocol packet.", ipHeader);
            return -2;
        }
        return 0;
    }

    public int processRevBuffer(byte[] bytes, int offset, int size) {
        int ret = 0;
        if (cacheBytesSize > 0) {
            System.arraycopy(bytes, offset, cacheBytes, cacheBytesSize, size);
            size = cacheBytesSize + size;
            cacheBytesSize = 0;
            ret = processRevBuffer(cacheBytes, 0, size);
            return ret;
        }
        if (size < IPHeader.IP4_HEADER_SIZE) {
            System.arraycopy(bytes, offset, cacheBytes, 0, size);
            cacheBytesSize = size;
            return 0;
        }

        IPHeader IpHeader = new IPHeader(bytes, offset);
        int totalLength = IpHeader.getTotalLength();
        if (totalLength <= 0 || totalLength > ProxyConfig.MUTE) {
            close(myVpnService.getString(R.string.rev_bad_length_packet));
            return -1;
        }
        if (totalLength < size) {
            ret = processRevPacket(bytes, offset, totalLength);
            if(ret != 0)
            {
                return ret;
            }
            int nextDataSize = size - totalLength;
            ret = processRevBuffer(bytes, (offset + totalLength), nextDataSize);
        } else if (totalLength == size) {
            ret = processRevPacket(bytes, offset, size);
        } else {
            System.arraycopy(bytes, offset, cacheBytes, 0, size);
            cacheBytesSize = size;
        }
        return ret;
    }


    @Override
    public void run() {
        int size = 0;
        try {
            byte[] bytes = new byte[ProxyConfig.MUTE];
            while (size != -1 && socketChannel.isOpen() && !closed) {
                size = socketChannel.read(ByteBuffer.wrap(bytes));
                if (size > 0) {
                    myVpnService.downDataBytes.addAndGet(size);
                    processRevBuffer(bytes, 0, size);
                }
            }
            close(myVpnService.getString(R.string.connect_server_do_close));
        } catch (IOException e) {
            if(AppDebug.IS_DEBUG){
                e.printStackTrace();
            }
            close(myVpnService.getString(R.string.connect_tunnel_error_closed));
        }
    }

    public int getVpnClientNum(){
        return vpnClientNum;
    }
    public int getMaxProxyNum(){
        return maxProxyNum;
    }

    public int getTcpProxyNum(){
        return tcpProxyNum;
    }

    public int getUdpProxyNum(){
        return udpProxyNum;
    }

    public int getUpDataBytes(){
        return upDataBytes;
    }

    public int getDownDataBytes(){
        return downDataBytes;
    }
}
