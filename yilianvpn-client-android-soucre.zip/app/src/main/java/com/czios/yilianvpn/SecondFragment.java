package com.czios.yilianvpn;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.czios.yilianvpn.databinding.FragmentSecondBinding;
import com.czios.yilianvpn.vpn.service.MyVpnService;
import com.czios.yilianvpn.vpn.utils.ProxyConfig;
import com.czios.yilianvpn.vpn.utils.VpnServiceHelper;
import com.google.android.material.snackbar.Snackbar;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;

    public static final String optionsPref ="vpnOptions";

    private final Handler handler = new Handler();

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Context ctx = binding.getRoot().getContext();
        //获取配置
        readOptins(ctx);

        binding.optionsIpValue.setText(ProxyConfig.SERVER_IP);
        binding.optionsPortValue.setText(ProxyConfig.SERVER_PORT + "");
        binding.optionsUserNameValue.setText(ProxyConfig.USER_NAME + "");
        binding.optionsUserPasswordValue.setText(ProxyConfig.USER_PWD + "");
        binding.optionsDns1Value.setText(ProxyConfig.DNS_FIRST);
        binding.optionsDns2Value.setText(ProxyConfig.DNS_SECOND);
        binding.optionsHttpProxyPortValue.setText(ProxyConfig.HTTP_PROXY_PORT + "");
        binding.optionsRunHttpProxy.setChecked((ProxyConfig.RUN_HTTP_PROXY == 1) ? true : false);

        binding.optionsRunHttpProxy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProxyConfig.RUN_HTTP_PROXY = binding.optionsRunHttpProxy.isChecked() ? 1 : 0;
                writeToPreference(ctx, "run_http_proxy", ProxyConfig.RUN_HTTP_PROXY + "");
            }
        });

        binding.optionsSaveBtn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View view) {
                closeVpn();
                ProxyConfig.SERVER_IP = binding.optionsIpValue.getText().toString();
                ProxyConfig.SERVER_PORT = Integer.parseInt(binding.optionsPortValue.getText().toString());
                ProxyConfig.USER_NAME = Integer.parseInt(binding.optionsUserNameValue.getText().toString());
                ProxyConfig.USER_PWD = Integer.parseInt(binding.optionsUserPasswordValue.getText().toString());
                ProxyConfig.DNS_FIRST = binding.optionsDns1Value.getText().toString();
                ProxyConfig.DNS_SECOND = binding.optionsDns2Value.getText().toString();
                ProxyConfig.HTTP_PROXY_PORT = Integer.parseInt(binding.optionsHttpProxyPortValue.getText().toString());
                ProxyConfig.RUN_HTTP_PROXY = binding.optionsRunHttpProxy.isChecked() ? 1 : 0;
                writeOptins(ctx);
                Snackbar snackbar = Snackbar.make(view, getString(R.string.save_success), Snackbar.LENGTH_SHORT);
                snackbar.setAction(getString(R.string.i_know), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // 用户点击了“了解”，关闭 Snackbar
                        snackbar.dismiss();
                    }
                });
                snackbar.show();
            }
        });

        binding.optionsBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(SecondFragment.this).navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
    private void closeVpn() {
        MyVpnService.errorMsg = getString(R.string.app_close_by_user);
        if (VpnServiceHelper.vpnRunningStatus()) {
            VpnServiceHelper.changeVpnRunningStatus(this.getContext(), false);
        }
    }

    public static  void readOptins(Context ctx){
        if(!getPreferenceValue(ctx, "ip").equals("0")){
            ProxyConfig.SERVER_IP= getPreferenceValue(ctx, "ip");
            ProxyConfig.SERVER_PORT = Integer.parseInt(getPreferenceValue(ctx, "port"));
            ProxyConfig.USER_NAME = Integer.parseInt(getPreferenceValue(ctx, "username"));
            ProxyConfig.USER_PWD = Integer.parseInt(getPreferenceValue(ctx, "user-password"));
            ProxyConfig.DNS_FIRST = getPreferenceValue(ctx, "dns1");
            ProxyConfig.DNS_SECOND = getPreferenceValue(ctx, "dns2");
            ProxyConfig.HTTP_PROXY_PORT = Integer.parseInt(getPreferenceValue(ctx, "http_proxy_port"));
            ProxyConfig.RUN_HTTP_PROXY = Integer.parseInt(getPreferenceValue(ctx, "run_http_proxy"));
        }
    }

    public static  void writeOptins(Context ctx){
        writeToPreference(ctx, "ip", ProxyConfig.SERVER_IP);
        writeToPreference(ctx, "port", ProxyConfig.SERVER_PORT + "");
        writeToPreference(ctx, "username", ProxyConfig.USER_NAME + "");
        writeToPreference(ctx, "user-password", ProxyConfig.USER_PWD + "");
        writeToPreference(ctx, "dns1", ProxyConfig.DNS_FIRST);
        writeToPreference(ctx, "dns2", ProxyConfig.DNS_SECOND);
        writeToPreference(ctx, "http_proxy_port", ProxyConfig.HTTP_PROXY_PORT + "");
        writeToPreference(ctx, "run_http_proxy", ProxyConfig.RUN_HTTP_PROXY + "");
    }
    public static String getPreferenceValue(Context ctx,String key)
    {
        SharedPreferences sp = ctx.getSharedPreferences(SecondFragment.optionsPref,0);
        return sp.getString(key,"0");
    }

    public static void writeToPreference(Context ctx, String key, String value)
    {
        SharedPreferences.Editor editor = ctx.getSharedPreferences(SecondFragment.optionsPref,0).edit();
        editor.putString(key, value);
        editor.apply();
    }
}