package com.czios.yilianvpn.vpn.tcpip;

import com.czios.yilianvpn.vpn.utils.CommonMethods;

/*
//icmp报文(能到达目的地,响应-请求包)
struct icmp8
{
    u_char icmp_type; //type of message(报文类型)
    u_char icmp_code; //type sub code(报文类型子码)
    u_short icmp_cksum;
    u_short icmp_id;
    u_short icmp_seq;
    char icmp_data[ 1];
};
*/
public class ICMPHeader {

    //uint8_t  type;
    public static final short offset_type = 0;
    //uint8_t code;
    public static final short offset_code = 1;
    //uint16_t check_sum;
    public static final short offset_check_sum = 2;
    public byte[] mData;
    public int mOffset;

    public ICMPHeader(byte[] data, int offset) {
        mData = data;
        mOffset = offset;
    }

    public byte getType() {
        return mData[mOffset + offset_type];
    }

    public void setType(byte value) {
        mData[mOffset + offset_type] = value;
    }

    public byte getCode() {
        return mData[mOffset + offset_code];
    }

    public void setCode(byte value) {
        mData[mOffset + offset_code] = value;
    }

    public short getCrc() {
        return CommonMethods.readShort(mData, mOffset + offset_check_sum);
    }

    public void setCrc(short value) {
        CommonMethods.writeShort(mData, mOffset + offset_check_sum, value);
    }

    public boolean ComputeIPChecksum(IPHeader ipHeader) {
        ipHeader.ComputeIPChecksum();
        int ipData_len = ipHeader.getDataLength();
        if (ipData_len < 0) {
            return false;
        }
        setCrc((short) 0);
        int sum = 0;
        // 将所有16位字相加
        int num = mOffset;
        while (ipData_len > 1) {
            sum += CommonMethods.readShort(mData, num)  & 0xFFFF;
            num += 2;
            ipData_len -= 2;
        }

        // 处理最后一个奇数字节
        if (ipData_len > 0) {
            sum += (mData[num] & 0xFF) << 8;
        }

        // 处理进位（回卷），直到高16位为0
        while ((sum >> 16) != 0) {
            sum = (sum & 0xFFFF) + (sum >> 16);
        }
        setCrc((short) ~sum);
        // 返回反码
        return true;
    }

    @Override
    public String toString() {
        return String.format("type=%s code=%s, checkSum=%d", getType(), getCode(), getCrc());
    }
}
